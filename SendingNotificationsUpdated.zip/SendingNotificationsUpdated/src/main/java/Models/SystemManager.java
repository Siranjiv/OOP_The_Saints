
package Models;


public class SystemManager {
public Interger Sys_ID;
public String Sys_name;


public String SaveStudentDetails()
{}
public String SendNotificationsToMarketingTeamMembers()
{}
public String SendEnrollmentLettersToStudent()
{}


}
