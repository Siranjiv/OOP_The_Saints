
package Models;


public class Student {
public Strings_name;
public String s_nic;
public Integer dob;
public Integer phone;
        
        
public String  setS_name()
{}
public String UpdateS_nic()
{}

}
