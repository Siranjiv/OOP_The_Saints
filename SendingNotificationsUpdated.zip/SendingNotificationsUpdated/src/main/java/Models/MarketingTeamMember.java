
package Models;


public class MarketingTeamMember {
   
public String M_id;
public String Position;
        
        
public String AcademicAdvertising()
{}
public String AcademicPromotion()
{}
}
