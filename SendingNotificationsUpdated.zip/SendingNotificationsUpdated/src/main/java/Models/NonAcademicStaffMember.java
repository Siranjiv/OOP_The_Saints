
package Models;


public class NonAcademicStaffMember {
public String name;
public Integer non_id;
        
public String setDuration()
{}
public String updateRequirements()
{}
public String updateCourses()
{}
public String TransferPathwayDetails()
{}
public String StudentRefistrations()
{}
public String AnswerEnquiries()
{}
public String SendNewStudentRedistrationDetailsToMarketingTeamMembers()
{}
public String GenerateEnrollmentLetter()
{}
}
