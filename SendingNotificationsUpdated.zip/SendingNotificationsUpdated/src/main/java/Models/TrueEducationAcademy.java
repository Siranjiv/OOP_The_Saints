/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

/**
 *
 * @author User
 */
public class TrueEducationAcademy {
public String Name;
public Integer Phone;
public String Address;
public String Email;
public String Web;
public String FB;
        
        
public String   updateFB()
{}
public StringUpdateWeb()
{}
}
