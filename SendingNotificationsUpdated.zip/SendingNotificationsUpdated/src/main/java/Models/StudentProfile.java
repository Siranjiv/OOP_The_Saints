
package Models;

public class StudentProfile {
    
public StringS_name;
public String S_nic;
   
public String AssignNewStudentID()
{}
public String UpdateStudentInfoToSID ()
{}
}
