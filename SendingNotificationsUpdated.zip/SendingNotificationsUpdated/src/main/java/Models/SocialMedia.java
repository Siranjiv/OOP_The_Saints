
package Models;

public class SocialMedia {
public String course_name;
public String duration;
public Integer cost;
public String transferPathways;

public String ProvideInformationAboutCourses()
{}
public String SendNotificationsToNonAcademicStaffMember()
{}
public String ProvideInstatntChatReply()
{}
}
