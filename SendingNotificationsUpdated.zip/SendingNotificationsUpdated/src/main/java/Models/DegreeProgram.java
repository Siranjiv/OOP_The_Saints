
package Models;

public class DegreeProgram {
   
    public String course_name ;
    public String duration;
    public Integer course-id;
    public String requirements;
    public Integer cost;

public Integer SetCost()
{}
public String updateRequiements()
{}
}
