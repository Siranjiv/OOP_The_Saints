/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

/**
 *
 * @author Anoli
 */
public class SystemManager {
public int Sys_ID;
public String Sys_name;

public SystemManager(int Sys_ID,String Sys_name){
this.Sys_ID=Sys_ID;
this.Sys_name=Sys_name;
}

public String Set_Sys()
{
return Sys_name;
}
public int get_sys_id()
{
return Sys_ID;
}





 @Override
     public String toString()
     {
         return Sys_ID+"\n"+Sys_name;
     }

}