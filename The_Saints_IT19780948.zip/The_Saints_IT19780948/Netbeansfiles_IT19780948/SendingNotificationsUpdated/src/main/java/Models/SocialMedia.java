/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;
/**
 *
 * @author Anoli
 */
public class SocialMedia {
public String course_name;
public String duration;
public int cost;
public String transferPathways;

public SocialMedia(String course_name,String duration,int cost,String transferPathways){
    this.course_name=course_name;
    this.duration=duration;
    this.cost=cost;
    this.transferPathways=transferPathways;
            
}

public String ProvideInformationAboutCourses()
{
    return course_name;
}
public String TransferPathwaysdetails()
{
    return transferPathways;
}



 @Override
     public String toString()
     {
         return course_name+"\n"+duration+"\n"+cost+"\n"+transferPathways;
     }

}