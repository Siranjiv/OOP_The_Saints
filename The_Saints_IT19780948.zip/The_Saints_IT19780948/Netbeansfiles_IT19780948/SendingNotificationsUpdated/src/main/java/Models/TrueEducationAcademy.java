/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

/**
 *
 * @author Anoli
 */
public class TrueEducationAcademy {
public String Name;
public int Phone;
public String Address;
public String Email;
public String Web;
public String FB;
        
public TrueEducationAcademy(String Name,int Phone,String Address,String Email,String Web,String FB){
this.Name=Name;
this.Phone=Phone;
this.Address=Address;
this.Web=Web;
this.FB=FB;
}
        
public String   updateFB()
{
return FB;
}
public String UpdateWeb()
{
return Web;
}


 @Override
     public String toString()
     {
         return Name+"\n"+Phone+"\n"+Address+"\n"+Email+"\n"+Web+"\n"+FB;
     }

}