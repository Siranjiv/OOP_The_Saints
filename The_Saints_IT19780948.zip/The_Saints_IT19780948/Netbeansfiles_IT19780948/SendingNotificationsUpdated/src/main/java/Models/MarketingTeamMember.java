/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;
/**
 *
 * @author Anoli
 */

public class MarketingTeamMember {
   
public String M_id;
public String Position;
public String Promotion_status;  
public String Advertising_status;

        public MarketingTeamMember(String M_id,String Position,String Promotion_status,String Advertising_status)
        {
         this.M_id=M_id;
         this.M_id=Position;
         this.Promotion_status=Promotion_status;
         this.Advertising_status=Advertising_status;
        }
        
public String update_memberID()
{
return M_id;
}

public String set_position ()
{
return Position;
}
public String AcademicAdvertising()
{
return Advertising_status;
}
public String AcademicPromotion()
{
return Promotion_status;
}


 @Override
     public String toString()
     {
         return M_id+"\n"+Position+"\n"+Promotion_status+"\n"+Advertising_status;
     }

}