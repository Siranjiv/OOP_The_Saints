/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;
/**
 *
 * @author Anoli
 */
public class DegreeProgram {
   
    public String course_name ;
    public int course_id;
    public String requirements;
    public int cost;

    public DegreeProgram(String course_name,int course_id,String requirements,int cost)
{
    this.course_name = course_name;
    this.course_id=course_id;
    this.requirements=requirements;
    this.cost=cost;
}
    
public Integer SetCost ()
{
return cost;
}
public String updateRequiements ()
{
return requirements;
}
public int setcourse_id ()
{
return course_id;
}

public String updateCourseName ()
{
return course_name ;
} 

        
        
        
@Override
     public String toString()
     {
         return course_name+"\n"+course_id+"\n"+requirements+"\n"+cost;
     }

}
