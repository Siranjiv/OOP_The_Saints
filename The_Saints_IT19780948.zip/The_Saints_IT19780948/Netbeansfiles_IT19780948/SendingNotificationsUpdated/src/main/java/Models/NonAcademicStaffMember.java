/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;
/**
 *
 * @author Anoli
 */

public class NonAcademicStaffMember {
public String name;
public int non_id;
public String Duration;
public String update_Requirement;
public String update_Courses;
public String Transfer_Pathway_Details;
public String Student_Refistrations;
public String Answer_Enquiries;
public String Send_NewStudentRedistration_Details_To_MarketingTeamMembers;
public String Generate_Enrollment_Letter;

    public NonAcademicStaffMember( String name,int non_id,String Duration,String update_Requirement,String update_Courses,String Transfer_Pathway_Details,String Student_Refistrations, String Answer_Enquiries,String Send_NewStudentRedistration_Details_To_MarketingTeamMembers,String Generate_Enrollment_Letter){
    {
    this.name=name;
    this.non_id=non_id;
    this.Duration=Duration;
    this.update_Requirement=update_Requirement;
    this.update_Courses=update_Courses;
    this.Transfer_Pathway_Details=Transfer_Pathway_Details;
    this.Student_Refistrations=Student_Refistrations;
    this.Answer_Enquiries=Answer_Enquiries;
    this.Send_NewStudentRedistration_Details_To_MarketingTeamMembers=Send_NewStudentRedistration_Details_To_MarketingTeamMembers;
    this.Generate_Enrollment_Letter=Generate_Enrollment_Letter;
    }

public int set_ID()
{
    return non_id;
}
public String getduration()
{
    return Duration;
}

public String updateRequirements()
{
return update_Requirement;
}
public String updateCourses()
{
return update_Courses;
}
public String TransferPathwayDetails()
{
return Transfer_Pathway_Details;
}
public String StudentRefistrations()        
{
return Student_Refistrations;
}
public String AnswerEnquiries()
{
return Answer_Enquiries;
}
public String SendNewStudentRedistrationDetailsToMarketingTeamMembers()
{
return Send_NewStudentRedistration_Details_To_MarketingTeamMembers;
}
public String GenerateEnrollmentLetter()
{
return Generate_Enrollment_Letter;
}
public String get_Name ()
{
return name;
}
 @Override
     public String toString()
     {
         return name+"\n"+non_id+"\n"+Duration+"\n"+update_Requirement+"\n"+update_Courses+"\n"+Transfer_Pathway_Details+"\n"+Student_Refistrations+"\n"+Answer_Enquiries+"\n"+Send_NewStudentRedistration_Details_To_MarketingTeamMembers+"\n"+Generate_Enrollment_Letter;
     }

}
