/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;
/**
 *
 * @author Anoli
 */
public class Student {
public String s_name;
public String s_nic;
public Integer dob;
public Integer phone;
        
public Student (String s_name,String s_nic, int dob,int phone ){
    this.s_name=s_name;
    this.s_nic=s_nic;
    this.dob=dob;
    this.phone=phone;
}
        
public String  setS_name()
{
return s_name;
}
public String UpdateS_nic()
{
return s_nic;
}



 @Override
     public String toString()
     {
         return s_name+"\n"+s_nic+"\n"+dob+"\n"+phone;
     }

}