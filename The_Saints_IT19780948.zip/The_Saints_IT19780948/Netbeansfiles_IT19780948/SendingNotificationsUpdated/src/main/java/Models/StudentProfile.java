/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;
/**
 *
 * @author Anoli
 */
public class StudentProfile {
    
public String S_name;
public String S_nic;
public int S_ID;
public StudentProfile( String S_name,String S_nic,int S_ID){
    this.S_name=S_name;
    this.S_nic=S_nic;
    this.S_ID=S_ID;
}
   
public int AssignNewStudentID()
{
return S_ID;
}

 @Override
     public String toString()
     {
         return S_name+"\n"+S_nic+"\n"+S_ID;
     }

}