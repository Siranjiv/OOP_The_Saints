/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DatabaseLayer;

/**
 *
 * @author Anoli
 */



import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;


public class Databaseconnection {
    public static Connection Connect() throws ClassNotFoundException{
        Connection con=null;
        Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        
        String url="jdbc:sqlserver://localhost:1433;databaseName=Saint;user=ss;Password=1234";
        
        try{
            con=DriverManager.getConnection(url);
            System.out.println("Succcessfully connected");
            
        }   
        catch (SQLException ex) {
                System.out.println(ex);
        }
        return con;
    } 

   
 
}

